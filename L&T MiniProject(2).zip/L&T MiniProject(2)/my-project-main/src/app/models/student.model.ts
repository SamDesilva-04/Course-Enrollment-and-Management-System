export interface Student {
  id: number;
  name: string;
  email: string;
  courseIds: number[]; // enrolled courses
}
